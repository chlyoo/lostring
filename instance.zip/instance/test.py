from enum import Enum
import json
class Mode(Enum):
  Category ='getLostGoodsInfoAccToClAreaPd'
  Place = 'getLostGoodsInfoAccTpNmCstdyPlace'
  Detail ='getLostGoodsDetailInfo'

PUBLIC_DATA_SERVICE_KEY = "FwsVHWbhbqPvERFzfu%2FMIRIvs1w4I6Ze9JujLeHIxZLyC9flKvkJVjOHC3LHAvoAOLtQnMa6vF2zYg8EhEE5Cw%3D%3D"
PUBLIC_DATA_REQUEST_URL1 = "http://apis.data.go.kr/1320000/LostGoodsInfoInqireService/{mode}?serviceKey={servicekey}&START_YMD={START_YMD}&END_YMD={END_YMD}&PRDT_CL_CD_01={PRDT_CL_CD_01}&PRDT_CL_CD_02={PRDT_CL_CD_02}&LST_LCT_CD={LST_LCT_CD}&pageNo={pageNo}&numOfRows={numOfRows}"
PUBLIC_DATA_REQUEST_URL2 = "http://apis.data.go.kr/1320000/LostGoodsInfoInqireService/getLostGoodsInfoAccTpNmCstdyPlace?serviceKey={servicekey}&LST_PLACE={LST_PLACE}&LST_PRDT_NM={LST_PRDT_NM}&pageNo={pageNo}&numOfRows={numOfRows}"
PUBLIC_DATA_REQUEST_URL3 = "http://apis.data.go.kr/1320000/LostGoodsInfoInqireService/getLostGoodsDetailInfo?servicekey={servicekey}&ATC_ID={ATC_ID}"
#parsing
import os#
import http
import urllib.request
from urllib.parse import quote

url = PUBLIC_DATA_REQUEST_URL1.format(mode =Mode.Category.value, servicekey= PUBLIC_DATA_SERVICE_KEY, START_YMD='20200320', END_YMD='20200920', PRDT_CL_CD_01='PRA000', PRDT_CL_CD_02='PRA300',LST_LCT_CD='LCA000',pageNo=1,numOfRows=10)
print(url)
request = urllib.request.Request(url)
response = urllib.request.urlopen(request)

rescode = response.getcode()
if (rescode == 200):
	try:
		response_body = response.read()
	except (http.client.IncompleteRead) as e:
		response_body = e.partial
	print(json.decode(response_body))
	parse = json.loads(response_body)
	print(parse)
	print(parse['items'])
	for ret in parse['items']:
		values = list(ret.values())
		print(values)